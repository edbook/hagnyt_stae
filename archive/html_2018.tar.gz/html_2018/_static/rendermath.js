document.addEventListener("DOMContentLoaded", function(event) {
    renderMathInElement(document.body);
});