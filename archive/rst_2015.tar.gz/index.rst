.. Stærðfræðigreining I documentation master file, created by
   sphinx-quickstart on Thu May 21 20:43:00 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Stærðfræðigreining I (STÆ104G), Háskóli Íslands, haust 2015 
=========================================================

Kennari: Benedikt Steinar Magnússon, bsm@hi.is.

.. todo::
    **Global**:
    
    - setja inn nauðsynlegar undirstöður fyrir hvern kafla
    
    - ensk heiti í sviga á eftir skilgreiningum?
    
    - liti á allar (sub(sub))sections?
    
    - Listi yfir setningar: *index:: setning; .....*
    
    - Formúlublað
    
    - táknalisti


.. toctree::
   :maxdepth: 2
   :numbered:
   :glob:

   kafli*

.. toctree::
	vidauki

* :ref:`genindex`


*Don't Panic.*

-- Douglas Adams, The Hitchhiker's Guide to the Galaxy
